#
# Cookbook Name:: inf
# Recipe:: git
#
# Copyright 2014, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

package 'git'
