#
# Cookbook Name:: inf
# Attributes:: inf
#

case node['platform']
when 'redhat', 'centos', 'scientific', 'fedora', 'suse', 'amazon', 'oracle', 'debian', 'ubuntu'

when 'mac_os_x'

end
